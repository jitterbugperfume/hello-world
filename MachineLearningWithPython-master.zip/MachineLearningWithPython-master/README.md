# MachineLearningWithPython
Starter files for Pluralsight course: Understanding Machine Learning with Python


## Edit history
Jan 05, 2019 - Updated references to deprecated functions in Pima-Prediction-with-reload.ipynb
